<?php

$koneksi = mysqli_connect('localhost', 'root', '', 'spp-terakhir');


?>


