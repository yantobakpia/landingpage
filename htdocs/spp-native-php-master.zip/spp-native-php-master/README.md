change database name like a your settings in koneksi.php dont forget for import pembayaran-spp.sql

Administrator: admin:admin
Petugas: petugas:petugas

siswa Nisn:nis = 1234:1234

create stored procedure ✔
create function ✔
